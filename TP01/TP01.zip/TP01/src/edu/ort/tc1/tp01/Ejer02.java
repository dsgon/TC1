package edu.ort.tc1.tp01;

/**
 * 
 * @author David Santiago Gonzalez
 * 
 * Curso: 1C
 * 
 * 
 * Realiz� un programa que, siendo num1 y num2 dos n�meros enteros con valor 4 y 5, 
 * respectivamente, muestre el resultado de la suma entre ambos n�meros, y luego el producto 
 * entre ambos. 
 *
 */

public class Ejer02 {
	
	public static void main(String[] args) {
	
		int num1 = 4, num2 = 5;
		
		System.out.println("El resultado de la suma es: "+(num1+num2));
		
		System.out.println("El producto de los numeros es: "+num1+num2);
	
	}

}
