package edu.ort.tc1.tp01;

 /**
 * 
 * @author David Santiago Gonzalez
 * 
 * Curso: 1C
 * 
 * Realiz� un programa donde se cree un n�mero entero num1, que inicialmente valdr� 0. 
 * Luego increment� su valor en 1 y mostralo por pantalla.  Despu�s mostr� el resultado de 
 * multiplicarlo por s� mismo. 
 *
 */

public class Ejer01 {

	public static void main(String[] args) {

		int num1 = 0;
		
		num1++;
		
		System.out.println(num1);
		
		System.out.println(num1*num1);

	}

}
